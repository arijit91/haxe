public class InvalidMoveException extends Exception {
	public static final long serialVersionUID = 42;
}